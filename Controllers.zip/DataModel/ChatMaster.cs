﻿namespace USAExportWorkflowWeb_V1.DataModel
{
    public class ChatMaster
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string? SenderId { get; set; }
        public string? ReceiverId { get; set; }
        public string? ReferenceNo { get; set; }
        public string? Comments { get; set; }
        public bool? Isread { get; set; }
        public DateTime? ReadTime { get; set; }
        public DateTime? SendTime { get; set; }
       
    }
}
