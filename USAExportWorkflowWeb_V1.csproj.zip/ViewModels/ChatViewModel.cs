﻿namespace USAExportWorkflowWeb_V1.ViewModels
{
    public class ChatViewModel
    {
        public string? Id { get; set; }
        public string? SenderId { get; set; }
        public string? ReceiverId { get; set; }
        public string? ReferenceNo { get; set; }
        public string? Comments { get; set; }
        public bool? Isread { get; set; }
        public DateTime? ReadTime { get; set; }
        public DateTime? SendTime { get; set; }
    }

    public class ChatsViewModel
    {
        public string? Sender { get; set; }
        public string? Receiver { get; set; }
        public string? ReferenceNo { get; set; }
        public string? Comments { get; set; }
        public string? ReadByUser { get; set; }
        public DateTime? ReadTime { get; set; }
        public DateTime? SendTime { get; set; }
    }
}
