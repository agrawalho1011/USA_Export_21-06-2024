﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace USAExportWorkflowWeb_V1.ViewModels
{
	public class RegisterViewModel
	{
		[Required]
		public string UserName { get; set; }
		[Required]
		public int EmpId { get; set; }		
		public string? CitrixId { get; set; }
		public string Role { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
        public bool? IsLDAP { get; set; } 
        public bool? IsReset { get; set; } 
        public bool? ChatEnable { get; set; }
        public List<IdentityRole>? RoleList { get; set; }
        public List<string>? assingedRoleList { get; set; }
    }
}
