﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using USAExportWorkflowWeb_V1.DataModel;
using USAExportWorkflowWeb_V1.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Drawing;
using System.Net;
using System.Globalization;
using System.Data;
using Microsoft.EntityFrameworkCore;

namespace USAExportWorkflowWeb_V1.Controllers
{
	public class UploadController : Controller
	{
		ApplicationDBContext _context;
		public UploadController(ApplicationDBContext context)
		{
			_context = context;
		}
		public IActionResult Index()
		{
			ViewBag.Countries = _context.CountryMaster.ToList();
			Console.WriteLine(ViewBag.Countries.Count);
			return View(new UploadViewModel());
		}

		[HttpPost]
		public async Task<IActionResult> Index(UploadViewModel model)
		{
			if (ModelState.IsValid)
			{
				// Save the uploaded file to the server
				var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", model.File.FileName);
				using (var stream = new FileStream(filePath, FileMode.Create))
				{
					await model.File.CopyToAsync(stream);
				}
				UploadFile1(filePath, model.UploadId);
			}
			// Return a response to the client
			return View();

		}


		public JsonResult UploadFile1(string filePath, string Upload)
		{
			_context.Database.SetCommandTimeout(300);
			DataTable Rawdata = new DataTable();
			List<FileMaster> filemaster = new List<FileMaster>();
			List<HBLMaster> hBLMaster = new List<HBLMaster>();

			if (Upload == "MainDump")
			{
				DataTable UploadRawdata = GeneralFunction.GetDataFromExcel(filePath);
				List<FileMaster> isfilepresent = _context.FileMaster.Include(x => x.Country).ToList();
				List<HBLMaster> ishblpresent = _context.HBLMaster.Include(x => x.File).Include(x => x.File.Country).ToList();
				try
				{
					var excludedOffices = new List<string>
					{
						"BOG", "BUE", "CUK", "GUA", "GYE",
						"MEX", "MTR", "MVD", "MXE", "PTY",
						"SAE", "SCL", "SSZ"
					};

					var filemasterdata = UploadRawdata.AsEnumerable().Where(x => !excludedOffices.Contains(x.Field<string>("Office").Trim())).
										GroupBy(x => new { fileno = x.Field<string>("Nr File"), countryId = x.Field<string>("Office") }).Select(g => g.First()).ToList();
					foreach (var dr in filemasterdata)
					{

						var duplicate = isfilepresent.Where(x => x.FileNumber == dr["Nr File"].ToString().Trim() && x.Country.CountryName == dr["Office"].ToString().Trim()).FirstOrDefault();
						if (duplicate == null)
						{
							FileMaster filemas = InsertIntoDB(dr);
							filemaster.Add(filemas);
							duplicate = filemas;
						}
						else
						{

							var cm = _context.CountryMaster.Where(x => x.CountryName == dr["Office"].ToString().Trim()).FirstOrDefault();
							if (duplicate.FileNumber != dr["Nr File"].ToString().Trim())
							{
								duplicate.FileNumber = dr["Nr File"].ToString().Trim();

							}
							if (duplicate.Etd != (Convert.ToDateTime(dr["ETD"])))
							{
								duplicate.Etd = (dr["ETD"] == "") ? null : Convert.ToDateTime(dr["ETD"]); ;

							}
							//duplicate.FileNumber = dr["Nr File"].ToString().Trim();
							duplicate.CountryId = cm.Id;

							//duplicate.Etd = (dr["ETD"] == "") ? null : Convert.ToDateTime(dr["ETD"]);
							//duplicate.EnterDate = DateTime.UtcNow;//Changes added by Ravindra Enter Date update
							_context.FileMaster.Update(duplicate);
						}
						/// HBL Entry here

						var hbls = UploadRawdata.AsEnumerable().Where(x => x.Field<string>("Nr File").Trim() == dr["Nr File"].ToString() && x.Field<string>("Office").Trim() == dr["Office"].ToString()).ToList();
						foreach (var drr in hbls)
						{
							var duplicatehbl = ishblpresent.Where(x => x.Booking == drr["Booking"].ToString().Trim()).FirstOrDefault();
							if (duplicatehbl == null)
							{
								hBLMaster.Add(new HBLMaster
								{
									HBLNumber = drr["House BL"].ToString().Trim(),
									FileId = duplicate.Id,
									CustomerName = drr["Company"].ToString().Trim(),
									Container = drr["Container #"].ToString().Trim(),
									Booking = drr["Booking"].ToString().Trim(),
									EnterDate = DateTime.UtcNow,

								});
							}
							else
							{
								if (duplicatehbl.HBLNumber != drr["House BL"].ToString().Trim())
								{
									duplicatehbl.HBLNumber = drr["House BL"].ToString().Trim();
								}
								if (duplicatehbl.CustomerName != drr["Company"].ToString().Trim())
								{
									duplicatehbl.CustomerName = drr["Company"].ToString().Trim();
								}
								if (duplicatehbl.Container != drr["Container #"].ToString().Trim())
								{
									duplicatehbl.Container = drr["Container #"].ToString().Trim();
								}
								if (duplicatehbl.Booking != drr["Booking"].ToString().Trim())
								{
									duplicatehbl.Booking = drr["Booking"].ToString().Trim();
								}
								duplicatehbl.FileId = duplicate.Id;
								//duplicatehbl.Container = drr["Container #"].ToString().Trim();
								//duplicatehbl.Booking = drr["Booking"].ToString().Trim();
								//duplicatehbl.EnterDate = DateTime.UtcNow;
								_context.HBLMaster.Update(duplicatehbl);
							}
						}
					}

					_context.FileMaster.AddRange(filemaster);
					_context.HBLMaster.AddRange(hBLMaster);
					_context.SaveChanges();
					return Json("Success");

				}
				catch (Exception ex)
				{
					return Json("error");
				}
			}
			else
			{
				//Read excel file data store in Datatable
				DataTable UploadRawdata = GeneralFunction.GetAllocateDataFromExcel(filePath);
				//Changes by ravi does not use below line in the code.
				//var isfilepresent = _context.FileMaster.ToList();
				//var ishblpresent = _context.HBLMaster.ToList();
				_context.Database.SetCommandTimeout(300);
				try
				{
					//Change by ravi is only one time using so i have change.
					var ActivityId = _context.ActivityMaster.Where(x => x.NameOfActivity == "LCL BL Entry").Select(x => x.Id).FirstOrDefault();
					var StatusId = _context.StatusMaster.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault();
					foreach (DataRow dr in UploadRawdata.Rows)
					{
						HBLMaster hbl_number = _context.HBLMaster.Where(x => x.Booking == dr["Booking Number"].ToString().Trim()).FirstOrDefault(); // x.HBLNumber == dr["HBL Number"].ToString().Trim()

						if (hbl_number != null)
						{
							HBLActivityLog hbllog = _context.HBLActivityLog.Where(x => x.HBLId == hbl_number.Id && x.ActivityId == ActivityId).FirstOrDefault();
							var userid = _context.Users.Where(x => x.EmpId == Convert.ToInt32(dr["User Id"].ToString().Trim().ToLower().Replace("u", " ").Trim())).Select(x => x.Id).FirstOrDefault();
							if (hbllog == null)
							{
								_context.HBLActivityLog.Add(new HBLActivityLog
								{
									HBLId = hbl_number.Id,
									StatusId = StatusId,
									ActivityId = ActivityId,
									UserId = userid,
									//StartDate = DateTime.UtcNow
								});
								_context.SaveChanges();
								//Code Added By Ravi on dated 25/01/2024
								HBLActivitylogHistory hBLActivitylogHistory = new HBLActivitylogHistory
								{
									HBLogId = hbl_number.Id,
									ActivityId = ActivityId,
									StatusId = StatusId,
									UserId = userid,
									StartDate = DateTime.UtcNow
								};
								_context.HBLActivitylogHistory.Add(hBLActivitylogHistory);
								_context.SaveChanges();
							}
						}
					}
				}
				catch (Exception ex)
				{
					return Json("error");
				}
				return Json("Success");
			}
		}


		//File Upload MainDump and Allocation 

		#region Do not use below code
		public JsonResult UploadFile12(string filePath, string Upload)
		{
			_context.Database.SetCommandTimeout(300);
			DataTable Rawdata = new DataTable();
			List<FileMaster> filemaster = new List<FileMaster>();
			List<HBLMaster> hBLMaster = new List<HBLMaster>();
			if (Upload == "MainDump")
			{
				DataTable UploadRawdata = GeneralFunction.GetDataFromExcel(filePath);

				var isfilepresent = _context.FileMaster.ToList();
				var ishblpresent = _context.HBLMaster.ToList();

				try
				{
					var filemasterdata = UploadRawdata.AsEnumerable().GroupBy(x => new { fileno = x.Field<string>("Nr File") }).Select(g => g.First()).ToList();

					foreach (DataRow dr in filemasterdata)
					{
						var duplicate = isfilepresent.Where(x => x.FileNumber == dr["Nr File"].ToString().Trim()).FirstOrDefault();

						if (duplicate == null)
						{
							try
							{
								FileMaster filemas = InsertIntoDB(dr);
								filemaster.Add(filemas);
							}
							catch (Exception ex)
							{

							}
						}
						else
						{
							try
							{
								var cm = _context.CountryMaster.Where(x => x.CountryName == dr["Office"].ToString().Trim()).FirstOrDefault();
								duplicate.FileNumber = dr["Nr File"].ToString().Trim();
								duplicate.CountryId = cm.Id;
								duplicate.Etd = (dr["ETD"] == "") ? null : Convert.ToDateTime(dr["ETD"]);

								_context.FileMaster.Update(duplicate);
							}
							catch (Exception ex)
							{

							}
						}
					}
				}
				catch (Exception ex)
				{
					return Json("error");
				}
				_context.FileMaster.AddRange(filemaster);
				_context.SaveChanges();

				//foreach(var hbldata in _context.FileMaster.ToList())
				//{
				//    var hbls = UploadRawdata.AsEnumerable().Where(x => x.Field<string>("Nr File").Trim() == hbldata.FileNumber).ToList();
				//}
				foreach (DataRow filedata in UploadRawdata.Rows)
				{
					if (filedata["Nr File"].ToString().Trim() == "DEL/NYC/0437888")
					{

					}
					var files = _context.FileMaster.Where(x => x.FileNumber == filedata["Nr File"].ToString()).FirstOrDefault();
					var hbldata = UploadRawdata.AsEnumerable().Where(x => x.Field<string>("Nr File").Trim() == filedata["Nr File"].ToString()).ToList();

					foreach (DataRow drr in hbldata)
					{
						var duplicate = ishblpresent.Where(x => x.Booking == drr["Booking"].ToString().Trim()).FirstOrDefault();
						if (duplicate == null)
						{
							hBLMaster.Add(new HBLMaster
							{
								HBLNumber = drr["House BL"].ToString().Trim(),
								FileId = files.Id,
								CustomerName = drr["Company"].ToString().Trim(),
								Container = drr["Container #"].ToString().Trim(),
								Booking = drr["Booking"].ToString().Trim(),
								EnterDate = DateTime.UtcNow,
							});
						}
						else
						{
							try
							{
								duplicate.HBLNumber = drr["House BL"].ToString().Trim();
								duplicate.FileId = files.Id;
								duplicate.CustomerName = drr["Company"].ToString().Trim();
								duplicate.Container = drr["Container #"].ToString().Trim();
								duplicate.Booking = drr["Booking"].ToString().Trim();
								_context.HBLMaster.Update(duplicate);
							}
							catch (Exception ex)
							{

							}
						}
					}
				}
				_context.HBLMaster.AddRange(hBLMaster);
				_context.SaveChanges();

				return Json("Success");
			}
			else
			{
				//Read excel file data store in Datatable
				DataTable UploadRawdata = GeneralFunction.GetAllocateDataFromExcel(filePath);
				_context.Database.SetCommandTimeout(300);
				var isfilepresent = _context.FileMaster.ToList();
				var ishblpresent = _context.HBLMaster.ToList();

				try
				{
					foreach (DataRow dr in UploadRawdata.Rows)
					{
						var ActivityId = _context.ActivityMaster.Where(x => x.NameOfActivity == "LCL BL Entry").Select(x => x.Id).FirstOrDefault();
						HBLMaster hbl_number = _context.HBLMaster.Where(x => x.Booking == dr["Booking Number"].ToString().Trim()).FirstOrDefault();  // x.HBLNumber == dr["HBL Number"].ToString().Trim()

						if (hbl_number != null)
						{
							HBLActivityLog hbllog = _context.HBLActivityLog.Where(x => x.HBLId == hbl_number.Id && x.ActivityId == ActivityId).FirstOrDefault();
							var userid = _context.Users.Where(x => x.EmpId == Convert.ToInt32(dr["User Id"].ToString().Trim().ToLower().Replace("u", " ").Trim())).Select(x => x.Id).FirstOrDefault();
							if (hbllog == null)
							{
								_context.HBLActivityLog.Add(new HBLActivityLog
								{
									HBLId = hbl_number.Id,
									StatusId = _context.StatusMaster.Where(x => x.Status == "WIP").Select(x => x.Id).FirstOrDefault(),
									ActivityId = ActivityId,
									UserId = userid,
									//StartDate = DateTime.UtcNow
								});
								_context.SaveChanges();
							}
						}
					}
				}
				catch (Exception ex)
				{
					return Json("error");
				}

				return Json("Success");
			}
		}

		#endregion

		public FileMaster InsertIntoDB(DataRow dr)
		{
			_context.Database.SetCommandTimeout(300);
			FileMaster efile = null;
			var cm = _context.CountryMaster.Where(x => x.CountryName == dr["Office"].ToString().Trim()).FirstOrDefault();
			if (cm == null)
			{
				_context.CountryMaster.Add(new CountryMaster
				{
					CountryName = dr["Office"].ToString().Trim()
				});
				_context.SaveChanges();
				cm = _context.CountryMaster.Where(x => x.CountryName == dr["Office"].ToString().Trim()).FirstOrDefault();
			}

			efile = new FileMaster
			{
				//Id = Guid.NewGuid().ToString(),
				FileNumber = dr["Nr File"].ToString().Trim(),
				EnterDate = DateTime.UtcNow,
				CountryId = cm.Id,
				Etd = dr["ETD"] == "" ? null : Convert.ToDateTime(dr["ETD"]),
			};

			return efile;
		}

		public HBLMaster InsertIntoHBLDB(DataRow dr)
		{
			_context.Database.SetCommandTimeout(300);
			HBLMaster ehbl = null;
			ehbl = new HBLMaster
			{
				//Id = Guid.NewGuid().ToString(),
				HBLNumber = dr["House BL"].ToString().Trim(),
				CustomerName = dr["Company"].ToString().Trim(),
				Container = dr["Container #"].ToString().Trim(),
				Booking = dr["Booking"].ToString().Trim(),
				EnterDate = DateTime.UtcNow,
			};

			return ehbl;
		}



		//Upload allocation and insert rowdump file and main data
		[HttpPost]
		public async Task<IActionResult> UploadFile(IFormFile file, string threadUpload)
		{
			_context.Database.SetCommandTimeout(300);
			if (file == null || file.Length == 0)
			{
				return BadRequest("Please select a file");
			}

			var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", file.FileName);
			//using (var stream = new FileStream(filePath, FileMode.Create))
			//{
			//    await file.CopyToAsync(stream);
			//}


			//var filePath = Path.GetTempFileName();
			var progress = new Progress<long>(totalBytes =>
			{
				var percentage = (double)totalBytes / file.Length * 100;
				HttpContext.Session.SetInt32("progress", (int)percentage);
			});

			using (var stream = new FileStream(filePath, FileMode.Create))
			{
				await file.CopyToAsync(stream);
			}
			UploadFile1(filePath, threadUpload);

			return Ok();
		}

	}
}
