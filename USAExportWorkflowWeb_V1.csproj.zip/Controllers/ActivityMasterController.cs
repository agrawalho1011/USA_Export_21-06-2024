﻿using USAExportWorkflowWeb_V1.DataModel;
using USAExportWorkflowWeb_V1.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace USAExportWorkflowWeb_V1.Controllers
{
	public class ActivityMasterController : Controller
	{
		private readonly ApplicationDBContext _context;

		public ActivityMasterController(ApplicationDBContext context)
		{
			_context = context;
		}

		// GET: ActivityMaster
		public async Task<IActionResult> Index()
		{
			return View(await _context.ActivityMaster.ToListAsync());
		}
		
		// GET: ActivityMaster/Create
		public IActionResult Create()
		{
			return View(new ActivityMaster());
		}

		// POST: ActivityMaster/Create
		// To protect from overposting attacks, enable the specific properties you want to bind to, for 
		// more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Create([Bind("Id,NameOfActivity,ActivityType,Source")] ActivityMaster activityMaster)
		{
			_context.Database.SetCommandTimeout(300);
			if (ModelState.IsValid)
			{
				_context.Add(activityMaster);
				await _context.SaveChangesAsync();
				return RedirectToAction(nameof(Index));
			}
			return View(activityMaster);
		}

		// GET: ActivityMaster/Edit/5
		public async Task<IActionResult> Edit(string? id)
		{
			_context.Database.SetCommandTimeout(300);
			if (id == null)
			{
				return NotFound();
			}

			var activityMaster = await _context.ActivityMaster.FindAsync(id);
			if (activityMaster == null)
			{
				return NotFound();
			}
			return View(activityMaster);
		}

		// POST: ActivityMaster/Edit/5
		// To protect from overposting attacks, enable the specific properties you want to bind to, for 
		// more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Edit(string id, [Bind("Id,NameOfActivity,ActivityType,Source")] ActivityMaster activityMaster)
		{
			_context.Database.SetCommandTimeout(300);
			if (id != activityMaster.Id)
			{
				return NotFound();
			}

			if (ModelState.IsValid)
			{
				try
				{
					_context.Update(activityMaster);
					await _context.SaveChangesAsync();
				}
				catch (DbUpdateConcurrencyException)
				{
					if (!ActivityMasterExists(activityMaster.Id))
					{
						return NotFound();
					}
					else
					{
						throw;
					}
				}
				return RedirectToAction(nameof(Index));
			}
			return View(activityMaster);
		}

		// GET: ActivityMaster/Delete/5
		public async Task<IActionResult> Delete(string? id)
		{
			_context.Database.SetCommandTimeout(300);
			if (id == null)
			{
				return NotFound();
			}

			var activityMaster = await _context.ActivityMaster
				.FirstOrDefaultAsync(m => m.Id == id);
			if (activityMaster == null)
			{
				return NotFound();
			}

			return View(activityMaster);
		}

		// POST: ActivityMaster/Delete/5
		[HttpPost, ActionName("Delete")]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> DeleteConfirmed(string id)
		{
			_context.Database.SetCommandTimeout(300);
			var activityMaster = await _context.ActivityMaster.FindAsync(id);
			_context.ActivityMaster.Remove(activityMaster);
			await _context.SaveChangesAsync();
			return RedirectToAction(nameof(Index));
		}

		//Activity is exits
		private bool ActivityMasterExists(string id)
		{
			return _context.ActivityMaster.Any(e => e.Id == id);
		}
	}
}
