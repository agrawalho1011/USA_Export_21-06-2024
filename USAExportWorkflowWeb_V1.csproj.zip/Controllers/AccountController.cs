﻿using USAExportWorkflowWeb_V1.DataModel;
using USAExportWorkflowWeb_V1.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Text.RegularExpressions;
using USAExportWorkflowWeb_V1.LDAP;
using Microsoft.AspNetCore.Authorization;

namespace USAExportWorkflowWeb_V1.Controllers
{
    //Handle Login and Register also logout 
   
	public class AccountController : Controller
	{
		private readonly UserManager<ApplicationUser> userManger;
		private readonly SignInManager<ApplicationUser> signInManager;
		private readonly RoleManager<IdentityRole> roleManager;
		public ApplicationDBContext _ctx;
        private readonly LdapUserManager<ApplicationUser> ldapUserManager;

        public AccountController(UserManager<ApplicationUser> userManger, SignInManager<ApplicationUser> signInManager, LdapUserManager<ApplicationUser> ldapUserManager, RoleManager<IdentityRole> roleManager, ApplicationDBContext ctx)
		{
			this.userManger = userManger;
			this.signInManager = signInManager;
			this.roleManager = roleManager;
			_ctx = ctx;
            this.ldapUserManager = ldapUserManager;
        }

		[HttpGet]
		public IActionResult Login()
		{
			return View(new LoginViewModel());
		}

		[HttpGet]
		public IActionResult Index()
		{
			_ctx.Database.SetCommandTimeout(120);
			ViewBag.Roles =_ctx.Roles.ToList();

			var result = _ctx.Users.Select(x => new RegisterViewModel
			{
				FirstName = x.FirstName,
				LastName = x.LastName,
				UserName = x.UserName,
				CitrixId = x.CitrixId,
				EmpId = x.EmpId,
                //Role = _ctx.UserRoles.Where(y => y.UserId == x.Id).FirstOrDefault().RoleId,
                RoleList = roleManager.Roles.ToList(),
                assingedRoleList = _ctx.UserRoles.Where(y => y.UserId == x.Id).Select(x => x.RoleId).ToList(),
                IsLDAP =x.IsLDAP,
				IsReset=x.IsReset,
				ChatEnable = x.ChatEnable
			}).ToList();
			return View(result);
		}

        //Login by the CitrixId by the roles User and Suprevisor
        //[HttpPost]
        //public async Task<IActionResult> Login(LoginViewModel model)
        //{
        //	if (ModelState.IsValid)
        //	{
        //		var result = await signInManager.PasswordSignInAsync(model.CitrixId, model.Password, false, false);
        //		if (result.Succeeded)
        //		{
        //			var user = await userManger.FindByNameAsync(model.CitrixId);
        //			var roles = await userManger.GetRolesAsync(user);
        //			if (roles.Count != 0)
        //			{
        //				if (roles[0].ToString() == "Supervisor" || roles[0].ToString() == "Manager")
        //				{
        //					return RedirectToAction("Index", "Dashboard");
        //				}
        //				else if (roles[0].ToString() == "User")
        //				{
        //					return RedirectToAction("Index", "User");
        //				}
        //				else
        //				{
        //					return NotFound();
        //				}
        //			}
        //		}
        //		//ModelState.AddModelError("", "Invalid Login Attempt");
        //		return View(model);
        //	}
        //	else
        //	{
        //		ModelState.AddModelError(string.Empty, "Invalid login attempt.");
        //		return View(model);
        //	}


        //}

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
			_ctx.Database.SetCommandTimeout(120);
			if (ModelState.IsValid)
            {
                ApplicationUser users = _ctx.Users.Where(x => x.CitrixId == model.CitrixId).FirstOrDefault();
                if (users == null)
                {
                    ModelState.AddModelError(string.Empty, "Invalid user id.");
                    return View(model);
                }
                if (users.IsLDAP == false)
                {
                    if (users.IsReset == false)
                    {
                        var result = await signInManager.PasswordSignInAsync(users, model.Password, false, false);
                        if (result.Succeeded)
                        {
                            var user = await userManger.FindByNameAsync(model.CitrixId);
                            var roles = await userManger.GetRolesAsync(user);

                            if (roles.Count != 0)
                            {
                                if (roles.Count() == 1)
                                {
                                    if (roles[0].ToString().ToUpper() == "SUPERVISOR" || roles[0].ToString().ToUpper() == "MANAGER")
                                    {
                                        return RedirectToAction("Index", "Dashboard");
                                    }
                                    else if (roles[0].ToString().ToUpper() == "USER")
                                    {
                                        return RedirectToAction("Index", "User");
                                    }
                                }
                                else
                                    return RedirectToAction("SelectRole", "User");
                            }
                            else
                                ModelState.AddModelError(string.Empty, "No roles assigned, Please contact Admin");

                        }
                        ModelState.AddModelError("", "Invalid Login Attempt");
                        return View(model);
                    }
                    else
                    {

                        return RedirectToAction("ChangePassword", "Account", new { Username = users.UserName });
                    }
                }
                else
                {
                    var result = await ldapUserManager.CheckPasswordAsync(users, model.Password);

                    if (result)
                    {
                        await signInManager.SignInAsync(users, isPersistent: false);
                        var user = await userManger.FindByNameAsync(model.CitrixId);
                        var roles = await userManger.GetRolesAsync(user);

                        if (roles.Count != 0)
                        {
                            if (roles.Count() == 1)
                            {
                                if (roles[0].ToString().ToUpper() == "SUPERVISOR" || roles[0].ToString().ToUpper() == "MANAGER")
                                {
                                    return RedirectToAction("Index", "Dashboard");
                                }
                                else if (roles[0].ToString().ToUpper() == "USER")
                                {
                                    return RedirectToAction("Index", "User");
                                }
                            }
                            else
                                return RedirectToAction("SelectRole", "User");
                        }
                        else
                            ModelState.AddModelError(string.Empty, "No roles assigned, Please contact Admin");

                    }
                    ModelState.AddModelError("", "Invalid Login Attempt");
                    return View(model);
                }
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                return View(model);
            }
        }

        //Register page load and get roles data
        [HttpGet]
		public IActionResult Register()
		{
			_ctx.Database.SetCommandTimeout(120);
			ViewBag.Roles = roleManager.Roles.ToList();
			return View(new RegisterViewModel());
		}
		//User Registration and Add user data in database
		[HttpPost]
		public async Task<IActionResult> Register(RegisterViewModel model)
		{
			_ctx.Database.SetCommandTimeout(120);
			Console.Write("--------------------------------------------------------------");
			Console.Write(model.Role);
			if (ModelState.IsValid)
			{
				var user = new ApplicationUser
				{
					CitrixId = model.UserName,
					EmpId = model.EmpId,
					UserName = model.UserName,
					FirstName = model.FirstName,
					LastName = model.LastName,
					IsActive = true,
					NormalizedUserName = model.UserName.ToUpper()
				};
				//Registration data added
				var result = await userManger.CreateAsync(user);
				_ctx.SaveChanges();

				if (result.Succeeded)
				{
					var roleId = _ctx.Roles.Where(x => x.Name == model.Role).Select(x => x.Id).FirstOrDefault();
					//Assign user by role
					_ctx.UserRoles.Add(new IdentityUserRole<string>
					{
						RoleId = roleId,
						UserId = user.Id,
					});

					//await userManger.AddToRoleAsync(user, model.Role);
					return RedirectToAction("Index", "Account");
				}
				foreach (var error in result.Errors)
				{
					ModelState.AddModelError("", error.Description);
				}
			}

			return View(model);
		}
		////Update user roles 
		//[HttpPost]
		//public async Task<JsonResult> UpdateRole(UpdateRoleModel data)
		//{
		//	var user = _ctx.Users.Where(x => x.CitrixId == data.CitrixId).FirstOrDefault();
		//	var userrole = _ctx.UserRoles.Where(x => x.UserId == user.Id).FirstOrDefault();

		//	if (user != null)
		//	{
		//		try
		//		{
		//			 _ctx.Remove(userrole);
		//			_ctx.UserRoles.Add(new IdentityUserRole<string>
		//			{
		//				RoleId = data.RoleId,
		//				UserId = user.Id,
		//			});

		//			_ctx.SaveChanges();
		//		}
		//		catch (Exception ex) { }
		//		return Json("success");
		//	}
		//	else
		//	{
		//		return Json("failed");
		//	}

		//}
		//Logout application
		public async Task<IActionResult> Logout()
		{
			_ctx.Database.SetCommandTimeout(120);
			await signInManager.SignOutAsync();
			return RedirectToAction("Login", "Account");
		}

		[HttpGet]

		public IActionResult EditUser(string Uname)
		{
			_ctx.Database.SetCommandTimeout(120);
			ViewData["EditUser"]= _ctx.Users.Where(x => x.UserName.ToLower() == Uname.Trim().ToLower()).FirstOrDefault();
			
			return PartialView();
		}

        [HttpPost]
        public async Task<JsonResult> EditUser(ApplicationUser model)
        {
			_ctx.Database.SetCommandTimeout(120);
			var uname = _ctx.Users.Where(x => x.Id == model.Id).FirstOrDefault();
            if (uname != null)
            {
				uname.FirstName = model.FirstName.Trim();
				uname.LastName = model.LastName.Trim();
				uname.UserName = model.UserName.Trim();
				uname.CitrixId = model.UserName.Trim();
				uname.NormalizedUserName = model.UserName.ToUpper().Trim();
                _ctx.Users.Update(uname);
                _ctx.SaveChanges();
                return Json("Updated Successfully..!");
            }
            else
            {
                return Json("Error while processing the request");
            }
        }

        [HttpGet]
        public IActionResult ChangePassword(string Username)
        {
			_ctx.Database.SetCommandTimeout(120);
			if (Username == null)
            {
                if (User.Identity.IsAuthenticated)
                {
                    Username = userManger.GetUserName(User).ToString();
                }
            }

            ViewData["roles"] = roleManager.Roles.ToList();
            ViewData["User"] = userManger.Users.FirstOrDefault(x => x.UserName == Username);

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        {
			_ctx.Database.SetCommandTimeout(120);
			//var user = await userManger.GetUserAsync(User);

			//if (user == null)
			//{
			//    // Handle the case where the user is not found
			//    return NotFound();
			//}

			if (ModelState.IsValid)
            {
                ApplicationUser user = new ApplicationUser();

                if (User.Identity.IsAuthenticated)
                {
                    user = await userManger.GetUserAsync(User);
                }
                else
                {
                    user = _ctx.Users.FirstOrDefault(x => x.UserName == model.Username);
                    user.IsReset = false;
                    _ctx.Update(user);
                }

                var result = await userManger.ChangePasswordAsync(user, model.CurrentPassword.Trim(), model.NewPassword.Trim());

                if (result.Succeeded)
                {
                    return Json("success");
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }

            ViewData["roles"] = roleManager.Roles.ToList();
            return View("ChangePassword", model);
        }


        private bool IsPasswordValid(string password)
        {
            // Add your password validation logic here
            // For example, using a regular expression
            const string passwordRegex = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,}$";
            return Regex.IsMatch(password, passwordRegex);
        }
        public IActionResult ResetPassword()
        {
			_ctx.Database.SetCommandTimeout(120);
			// Retrieve users based on role (in this case, "user")
			ViewData["User"] = _ctx.Users.ToList();
            return View();
        }

        // POST: /User/GeneratePassword
        [HttpPost]
        public IActionResult GeneratePassword(string userName)
        {
			_ctx.Database.SetCommandTimeout(120);
			// Generate random password
			string newPassword = GenerateRandomPassword();
            newPassword = newPassword.Trim();

            // Update user's password
            var user = userManger.FindByNameAsync(userName).Result;
            var token = userManger.GeneratePasswordResetTokenAsync(user).Result;
            var result = userManger.ResetPasswordAsync(user, token, newPassword).Result;


            if (result.Succeeded)
            {
                // Save the new password to the database or perform any other necessary actions
                // You can add code here to save the newPassword to the database
                // For simplicity, I'll assume you have a method like SavePasswordToDatabase(userId, newPassword)

                // SavePasswordToDatabase(userId, newPassword);

                // Return the new password to the view
                return Json(new { newPassword });
            }
            else
            {
                // Handle password reset failure
                return Json(new { error = "Password reset failed." });
            }
        }

        //private string GenerateRandomPassword()
        //{
        //    // Implement your logic to generate a random password here
        //    // For simplicity, I'll generate a random string of length 8
        //    const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~!@#$%^&*()_+/`';.,/][}{:?><";
        //    var random = new Random();
        //    return new string(Enumerable.Repeat(chars, 12)
        //      .Select(s => s[random.Next(s.Length)]).ToArray());
        //}


        // While creating random password check validation for must contain at least 1 digit one uppercase and one special character
        private string GenerateRandomPassword()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~!@#$%^&*()_+/`';.,/][}{:?><";
            var random = new Random();

            // Generate until the password meets the requirements
            string newPassword;
            do
            {
                newPassword = new string(Enumerable.Repeat(chars, 12)
                  .Select(s => s[random.Next(s.Length)]).ToArray());
            } while (!PasswordMeetsRequirements(newPassword));

            return newPassword;
        }

        private bool PasswordMeetsRequirements(string password)
        {
            // Check if the password contains at least one digit, one uppercase letter, and one special character
            return password.Any(char.IsDigit) && password.Any(char.IsUpper) && password.Any(char.IsLower) && password.Any(IsSpecialCharacter);
        }

        private bool IsSpecialCharacter(char c)
        {
            const string specialCharacters = "~!@#$%^&*()_+/`';.,/][}{:?<>";

            // Check if the character is a special character
            return specialCharacters.Contains(c);
        }

        [Authorize(Roles = "Supervisor,Manager")]
        [HttpPost]
        public async Task<JsonResult> UpdateRoles([FromBody] UpdateRoleModel assignedRole)
        {
			_ctx.Database.SetCommandTimeout(120);
			var users = _ctx.Users.Where(x => x.CitrixId == assignedRole.UserId).FirstOrDefault();
            var userrole = _ctx.UserRoles.Where(x => x.UserId == users.Id).ToList();
            try
            {
                _ctx.RemoveRange(userrole);

                if (assignedRole.RoleList != null)
                    foreach (var multi in assignedRole.RoleList)
                    {
                        _ctx.UserRoles.Add(new IdentityUserRole<string>
                        {
                            UserId = users.Id,
                            RoleId = multi.RoleId,
                        });
                    }

                _ctx.SaveChanges();
                return Json("success");

            }
            catch (Exception ex)
            {
                return Json("failed");
            }
        }
    }
}
